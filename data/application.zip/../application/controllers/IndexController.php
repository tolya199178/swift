<?php

class IndexController extends Swift_Controller_Action
{

    public function init(){
      
    }

	/**
	* Homepage
	*/
    public function indexAction(){
   
        
    }
    

    
}

