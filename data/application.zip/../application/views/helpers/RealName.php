<?php

class Zend_View_Helper_RealName {

    public $view;

    public function setView(Zend_View_Interface $view) {
        $this->view = $view;
    }

    public function realName($username) {
    	$usersModel = new Users;
    	$user = $usersModel->getUserByUsername($username);
    	
    	return $user->name;
    }
}
?>
