<?php

class Users extends Zend_DB_Table
{
	protected $_name = 'users';

	 /**
     * Get user info
     * @param type $userid
     * @return type user
     */
    public function getUser($userid){
        $select = $this->select()
                        ->from($this->_name)
                        ->where('userid=?',$userid);
        $result = $this->fetchRow($select);
        return $result;
    }
    
     /**
     * Get user info
     * @param type $username
     * @return type user
     */
    public function getUserByUsername($username){
        $select = $this->select()
                        ->from($this->_name)
                        ->where('username=?',$username);
        $result = $this->fetchRow($select);
        return $result;
    }
    
    
     /**
     * Update user table
     * @param type $userid -  id of user to be updated
     * @param type $data - array of key value pairs for table
     */
    function updateUser($userid,$data){
        $where =  "userid = " . $userid;
        $this->update($data,$where);
        return true;
    }
 

}

